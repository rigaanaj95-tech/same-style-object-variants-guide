# Quality Check Reference

Use this reference to decide whether generated variants are close enough to the reference style and how to refine them.

## Same-style checklist

A candidate is usable when it passes most of these checks:

- Style: medium and rendering style match the reference, whether it is hand-drawn illustration, flat graphic poster, collage, product render, or photorealistic photography.
- Camera: viewpoint, cropping, and perspective match the reference.
- Materials or mark-making: surfaces, textures, linework, brushwork, fills, or graphic shapes match the reference.
- Lighting or graphic treatment: shadow direction, softness, contrast, line weight, flatness, grain, or highlight style feel consistent.
- Palette: dominant and accent colors match the reference palette.
- Composition: object count, order, spacing, and scale follow the prompt.
- Background: scene or platform treatment is compatible with the reference.
- Usability: the object silhouette is clear enough for design composition, cropping, or masking.

## Common failures and fixes

| Failure | Likely cause | Refinement |
| --- | --- | --- |
| Output ignores the reference medium | Prompt forces a different style such as photorealism or illustration | Restate the exact reference medium, rendering style, linework, color treatment, and typography |
| Wrong object count | Count buried too late in prompt | Move exact count into target variant and avoid list |
| Camera angle drifts | Viewpoint is vague | Specify top view, elevated front view, or three-quarter view consistently |
| Object order is wrong | Layout constraints are too loose | State left-to-right or front-to-back order explicitly |
| Materials or linework feel mismatched | Style details are missing | Add surface, finish, texture, line weight, fill style, shadow, or mark-making details |
| Colors drift from reference | Palette is too broad | Name dominant colors and forbid unrelated accent colors |
| Background is cluttered | Model adds scene context | Require minimal clean background or same display platform |
| Candidate is close but not final | Generation solved style, not layout | Keep candidate and fix in retouching or Illustrator |

## Refinement loop

1. Pick the closest candidate rather than restarting from scratch.
2. Identify the top 1 to 3 mismatches only.
3. Rewrite the prompt with concrete corrections.
4. Regenerate a small batch.
5. Move to post-processing once style is close and only layout or color needs adjustment.

## Post-processing guidance

Use AI retouching or design tools when:

- The image matches style but needs small object movement or count cleanup.
- The color palette is close but needs brand or campaign alignment.
- The view is close but needs a slight top-view or crop adjustment.
- Multiple useful generated assets need to be combined into one composition.

Recommended final checks:

- Remove accidental text, logos, watermarks, and extra props.
- Align shadows, linework, or graphic fills after object masking or recomposition.
- Match the reference palette or user-specified campaign colors consistently.
- Keep editable source layers when the asset will enter a design file.
- Export a clean source image and a final composition-ready version when possible.
