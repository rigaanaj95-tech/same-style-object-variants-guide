# Prompting Reference

Use this reference when drafting prompts for same-style object, scene, or material variants.

## Style brief structure

Create a reusable style brief with this order:

```text
Reference style:
[medium/rendering style] [object/scene/material category] arranged as [composition].
Camera/view: [top view/front view/three-quarter view], [lens distance], [cropping].
Materials or mark-making: [ceramic/glass/metal/fabric] or [line weight/brush texture/flat fills].
Lighting: [soft studio light/natural light], [shadow direction], [shadow softness].
Color palette: [dominant colors], [accent colors], [saturation/contrast].
Background: [plain/gradient/scene/platform], [cleanliness], [depth].
Composition rules: [object count], [spacing], [scale relationship], [order].
Rendering style: [photorealistic/product render/flat illustration/hand-drawn poster/collage/etc.], [level of polish].
```

Keep this brief stable between variants. Only change target objects and explicit composition constraints.

## Image-to-text prompt

Use this when asking an AI model to describe the reference image before generating new assets:

```text
Please analyze this reference image for style replication. Describe only observable visual traits, not subjective brand language.

Extract:
1. Subject and object categories
2. Camera angle and framing
3. Materials, textures, and finishes
4. Lighting, shadows, and contrast
5. Color palette and saturation
6. Background and platform treatment
7. Composition, object spacing, scale, and ordering
8. Medium and rendering style

Then summarize the reusable style rules in one compact paragraph that can be reused in text-to-image prompts.
```

## Text-to-image prompt

Use this structure for each target variant:

```text
Create a same-style object or scene variant based on this style brief:
[paste reusable style brief]

Target variant:
- Objects: [specific objects]
- Quantity: [exact count]
- Layout: [position/order/spacing]
- Viewpoint: [required angle]
- Color and material constraints: [constraints]
- Background: [match reference or specify]
- Output: [single image/transparent cutout/poster-ready material/composition layer]

Must match the reference style in medium, rendering style, lighting or mark-making, palette, camera angle, composition rhythm, typography or graphic treatment.
```

## Negative prompt or avoid list

Add an avoid list when the model tends to drift:

```text
Avoid: cartoon style, illustration, exaggerated perspective, extra objects, incorrect object count, messy background, heavy decorative elements, over-saturated colors, inconsistent shadows, low-resolution texture, distorted geometry, unreadable product shape, mismatched camera angle.
```

## Batch strategy

For stable exploration, generate 3 to 6 variants per batch:

- Batch 1: keep layout closest to the reference; only change the target object.
- Batch 2: adjust placement, count, or order if Batch 1 is visually close.
- Batch 3: refine material, color, and shadow details after selecting the best candidate.

Do not vary style, camera angle, palette, and object count all at once. Change one or two controllable dimensions per batch.

## Image2 generation step

When the user asks to use image2, treat the model as the execution step after prompt drafting:

```text
Model/tool: image2
Reference image role: style and composition reference, not an exact object copy
Task: generate same-style object or scene variants
Batch size: 3 images unless the user asks otherwise
Prompt: [final text-to-image prompt]
Avoid list: [negative prompt]
Selection target: choose the image closest to the current reference image in medium, rendering style, palette, composition, spacing, typography or graphic treatment, lighting or mark-making, and overall visual mood
```

If the model supports image reference strength, use medium-to-high style reference strength but keep target objects free to change. If it supports seed/settings, record them with the selected output so the next refinement can stay stable.

## Example: monochrome product poster

```text
Style analysis summary:
The reference is a minimal monochrome product poster with a black outer border, warm off-white paper background, large negative space, a single black product photographed with strong silhouette contrast, and restrained editorial typography. The product sits partly off-frame to create tension, with crisp lighting, soft tonal gradients, and a clean catalog-advertising mood.

Reusable style brief:
Minimal monochrome editorial product poster, black outer border, warm off-white paper field, generous negative space, realistic black product photography with strong silhouette, crisp studio lighting, subtle soft shadows, sparse Swiss-style typography, one bold single-word headline, small information text block, clean premium catalog advertising mood.

Generation prompt:
Create a realistic same-style product poster based on this style brief: minimal monochrome editorial product poster, black outer border, warm off-white paper field, generous negative space, realistic black product photography with strong silhouette, crisp studio lighting, subtle soft shadows, sparse Swiss-style typography, one bold single-word headline, small information text block, clean premium catalog advertising mood.

Target variant: one modern black sofa replacing the original product. Place the sofa partly off-frame in the lower right or upper right area, with a strong realistic silhouette and clean fabric or leather texture. Keep the large off-white negative space and editorial poster layout. Use a bold single-word headline such as "Sofa." and a small understated information block. No brand logo.

Avoid: colorful background, extra furniture, lifestyle room scene, clutter, decorative props, brand logo, watermark, cartoon style, distorted sofa geometry, busy typography.
```
