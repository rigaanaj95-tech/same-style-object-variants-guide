---
name: same-style-object-variants
description: Use when the user wants to generate object, scene, or material variants that match the style of a reference image, especially workflows that use image-to-text analysis, prompt refinement, text-to-image generation, selection, retouching, color adjustment, or asset composition. Match the reference style by default; only force realism when the user explicitly asks for realistic output.
metadata:
  short-description: Generate variants from a reference style
---

# Same Style Object Variants

Use this skill to turn a reference visual into stable, reusable prompts and review steps for generating object, scene, or material variants in the same style.

This skill is intentionally scoped to same-style object, scene, or asset variants. Do not expand it into a full UED design restoration, campaign design, or page layout workflow unless the user asks for that broader task.

## Invocation

Explicit trigger name: `$same-style-object-variants`

Use or suggest this skill when the user says things like:

- "基于这张参考图生成同风格物体变体"
- "保持这个风格，帮我出一组素材"
- "先图生文，再文生图，稳定生成同风格变体"
- "这个物体风格很好，帮我换成其他物体但保持风格一致"

## Required inputs

Before generating final prompts, identify or ask for:

- Reference image or clear description of the source visual
- Target object variants to create
- Quantity requirements, such as number of items or variants
- Viewpoint and layout constraints, such as top view, left-right order, spacing, scale, or object count
- Final use case, such as poster asset, product card, icon-like cutout, design exploration, or composition material
- Tool target, if known, such as ChatGPT image generation, Jimeng, Lovart image2, Midjourney, Adobe Illustrator, or a manual design workflow

If the user has not provided an image, work from their description but call out that style stability will be weaker without a visual reference.

## Workflow

1. Analyze the reference image before writing generation prompts.
   Capture the stable style DNA: subject category, medium, rendering style, materials or linework, camera angle, lighting, shadows, background treatment, color palette, typography or graphic treatment, composition rhythm, object scale, and decorative elements.

2. Convert the visual style into a concise image-to-text style brief.
   Keep factual visual details. Avoid vague premium words unless tied to observable traits. The style brief should be reusable across multiple target objects.

3. Generate text-to-image prompts for the requested variants.
   Preserve the style brief, then swap in the target objects and constraints. Include exact object count, placement, order, camera angle, proportions, background, and output format when relevant.

4. Produce multiple prompt options or batches.
   Vary only the target object details and controllable composition choices. Keep style, camera, lighting, and palette stable across the batch.

5. Generate images with the target image model.
   If the user names a tool or model such as image2, Jimeng, Lovart image2, or ChatGPT image generation, adapt the prompt to that target and run or instruct the generation step directly when the tool is available. Generate 3 to 6 images per batch, then keep the prompt, seed/settings if available, and the selected candidate notes together for iteration.

6. Review outputs against the reference.
   Choose the closest candidates first. Then refine prompts around concrete mismatches: object placement, quantity, angle, material, scale, color, shadow, background, or clutter.

7. Prepare post-processing guidance.
   When the generated image is close but not final, describe edits for AI retouching, Illustrator, Photoshop, or other design tools: color matching, cropping, top-view adjustment, object masking, layer composition, spacing cleanup, and final asset export.

## Output format

When using this skill, return:

- Style analysis summary
- Reusable style brief
- Generation prompt or prompt batch
- Image generation step, including target model/tool when known
- Negative prompt or avoid list
- Variant strategy
- Selection and refinement checklist
- Post-processing notes when needed

For detailed prompt templates, read `references/prompting.md`. For review criteria and repair strategies, read `references/quality-check.md`.

## Guardrails

- Keep prompts specific and observable.
- Prioritize stable style over novelty.
- Match the reference image's medium and rendering style by default. Do not force photorealism unless the user explicitly asks for realistic output.
- Use image-to-text before text-to-image when a reference image is available.
- Do not promise exact visual identity from text alone.
- Do not include or reuse private reference images unless the user has provided them for the current task.
